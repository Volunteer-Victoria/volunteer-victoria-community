"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const serverless_express_1 = require("@vendia/serverless-express");
const app_1 = require("./app");
let cachedServer;
async function bootstrap() {
    if (!cachedServer) {
        const app = await (0, app_1.createNestApp)();
        cachedServer = (0, serverless_express_1.default)({ app });
    }
    return cachedServer;
}
const handler = async (event, context, callback) => {
    const cachedServer = await bootstrap();
    return cachedServer(event, context, callback);
};
exports.handler = handler;
//# sourceMappingURL=lambda.js.map