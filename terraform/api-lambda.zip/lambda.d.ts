import { Handler } from 'aws-lambda';
export declare const handler: Handler;
