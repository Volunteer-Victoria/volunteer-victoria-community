export declare function createNestApp(): Promise<import("express-serve-static-core").Express>;
