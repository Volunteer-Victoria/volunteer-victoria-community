"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createNestApp = void 0;
const express_1 = require("express");
const core_1 = require("@nestjs/core");
const platform_express_1 = require("@nestjs/platform-express");
const app_module_1 = require("./app.module");
async function createNestApp() {
    const app = (0, express_1.default)();
    const nestApp = await core_1.NestFactory.create(app_module_1.AppModule, new platform_express_1.ExpressAdapter(app));
    await nestApp.init();
    return app;
}
exports.createNestApp = createNestApp;
//# sourceMappingURL=app.js.map